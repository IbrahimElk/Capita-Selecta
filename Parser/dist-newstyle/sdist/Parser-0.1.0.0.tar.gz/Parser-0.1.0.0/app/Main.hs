{-# LANGUAGE ExistentialQuantification #-}
{-# OPTIONS_GHC -Wall #-}
{-# LANGUAGE TypeOperators #-}
{-# OPTIONS_GHC -Wno-unused-do-bind #-}
{-# OPTIONS_GHC -Wno-unrecognised-pragmas #-}
{-# HLINT ignore "Use <$>" #-}
{-# OPTIONS_GHC -Wno-unused-top-binds #-}
{-# HLINT ignore "Use newtype instead of data" #-}

-- TODO: breidt het uit voor RL agent, 
-- question : hoeveel rewards heb je verzamelt ? 
-- robot in maze state. 
-- de rewards worden dan door de Update geupdate. 
-- model a markov decision process. 

-- TODO: DOOR DE CODE GAAN EN ALLES BEGRIJPEN EN DOCUMENTEREN. 
-- DAARNA, ZONDER TE KIJKEN NAAR DEZE CODE, SCHRIJF VAN SCRATCH EIGEN VERSIE. 
-- DAARNA, STUUR MAIL NAAR PROF, kijken wat je nog kunt doen, of  
-- dit zodat het niet duidelijk is, dat er nog wa research in was gegaan. 
-- pushen naar github, en de link doorsturen naar de prof. 

-- TODO: 
-- hangt af van applicatie denk ik, er is geen algemene functie voor s ~> s natuurlijk.
-- en er kunnen meerdere zijn van die type. 
-- dus die functies moet op voorhand geweten zijn. 
-- dus een applicatie domein is nodig. 
-- mss van example folder een voorbeeld vinden of mss zoals problog, 
-- een probabilitische calculator ?
-- zie hieronder -> evaluate functie.

-- PROBLEEM1: 
-- geen idee wat 'observe' eig analoog is aan in een programma?

-- PROBLEEM2:
-- volgens quickcheck paper, kun je niet zomaar samplen van een generieke type. 
-- ik moet dus een Gen a definieren bv. 
-- sample :: Dist Bool -> Bool
-- sample (D dist) = error "..."
-- TODO: Mailtje sturen naar prof voor deze functie. 

-- TODO: is het niet beter eerder : While (s ~> Bool) (Kuifje s) (Kuifje s), hoe anders uit de body geraken ?  


module Main (main) where

-- import qualified Text.Parsec as P
-- import Data.Map
import qualified Control.Monad.State as S
import qualified Data.Map as M
import qualified System.Random as R
import qualified Text.Parsec as P
import qualified Text.Parsec.String as PS
import Data.Map.Strict ( elems, mapWithKey, singleton )
import Graphics.Rendering.Chart.Easy
import Graphics
type Prob = Rational
newtype Dist a = D { runD :: M.Map a Prob }

type a ~> b = a -> Dist b


data Kuifje s
  = Skip
  | Update (s ~> s) (Kuifje s)
  | If (s ~> Bool) (Kuifje s) (Kuifje s)
  | While (s ~> Bool) (Kuifje s)
  | forall o. (Ord o, Show o) => Observe (s ~> o) (Kuifje s)

instance Semigroup (Kuifje s) where
  Skip        <> k = k
  Update f p  <> k = Update f (p <> k)
  While c p   <> k = While c (p <> k)
  If c p q    <> k = If c p (q <> k)
  Observe f p <> k = Observe f (p <> k)

instance Monoid (Kuifje s) where
  mempty = Skip
  mappend = (<>)

skip :: Kuifje s
skip = Skip

update' :: (s ~> s) -> Kuifje s
update' f = Update f skip

while :: (s ~> Bool) -> Kuifje s -> Kuifje s
while c p = While c p

cond :: (s ~> Bool) -> Kuifje s -> Kuifje s -> Kuifje s
cond c p q = If c p q

observe :: (Ord o, Show o) => (s ~> o) -> Kuifje s
observe o = Observe o skip

-- -----------------------------------------
-- IMPLEMENTATIE VAN EEN PARSER:
-- -----------------------------------------

kuifjeParser :: PS.Parser (Kuifje Int)
kuifjeParser = skipParser P.<|> updateParser P.<|> ifParser P.<|> whileParser -- <|> observeParser

skipParser :: PS.Parser (Kuifje Int)
skipParser = do
    P.string "Skip"
    return Skip

updateParser :: PS.Parser (Kuifje Int)
updateParser = do
  P.string "Update"
  P.spaces
  f <- probParser
  P.spaces
  P.char '('
  P.spaces
  p <- kuifjeParser
  P.spaces
  P.char ')'
  return (Update f p)

ifParser :: PS.Parser (Kuifje Int)
ifParser = do
  P.string "If"
  P.spaces
  c <- binaryProbParser
  P.spaces
  P.char '('
  P.spaces
  p <- kuifjeParser
  P.spaces
  P.char ')'
  P.spaces
  P.char '('
  P.spaces
  r <- kuifjeParser
  P.spaces
  P.char ')'
  return (If c p r)

whileParser :: PS.Parser (Kuifje Int)
whileParser = do
  P.string "While"
  P.spaces
  c <- binaryProbParser
  P.spaces
  P.char '('
  P.spaces
  p <- kuifjeParser
  P.spaces
  P.char ')'
  return (While c p)


-- given some strings that correspond to function name of type s ~> s, 
-- return that function. 
probParser :: PS.Parser (Int ~> Int)
probParser = P.try (P.string "statement1" >> return statement1) P.<|>
             P.try (P.string "statement3" >> return statement3) P.<|>
             P.try (P.string "statement4" >> return statement4)

-- given some strings that correspond to function name of type s ~> Bool, 
-- return that function. 
binaryProbParser :: PS.Parser (Int ~> Bool)
binaryProbParser =  P.string "statement2" >> return statement2

-- ------------------------------------
-- evaluator function : 
-- ------------------------------------

evaluate :: Int -> Kuifje Int -> Int
evaluate x Skip = x

evaluate state (Update f next) = do
  let newDist = f state
      newState = sampleInt newDist
  evaluate newState next

evaluate state (If condStmt trueBranch falseBranch) = do
  let condDist = condStmt state
      condResult = sampleBool condDist
  if condResult
    then evaluate state trueBranch
    else evaluate state falseBranch

evaluate state (While condStmt body) = do
  let condDist = condStmt state
      condResult = sampleBool condDist
  if condResult
    then do
      let
        newState = evaluate state body
      evaluate newState (While condStmt body)
    else
      state

evaluate _ _ = error "nice"

-- point estimate for distribtuion.
average :: Dist Int -> Rational
average = sum . mapWithKey multiplyIntRational . runD

sampleInt :: Dist Int -> Int
sampleInt =  rationalToInteger . average

sampleBool :: Dist Bool -> Bool
sampleBool = intToBool . sampleInt . boolDistToIntDist

-- -------
-- Utils
-- -------

multiplyIntRational :: Int -> Rational -> Rational
multiplyIntRational int rational = toRational int * rational

rationalToInteger :: Rational -> Int
rationalToInteger = round

boolToInt :: Bool -> Int
boolToInt True  = 1
boolToInt False = 0

intToBool :: Int -> Bool
intToBool 1 = True
intToBool 0 = False
intToBool _ = error "nice"

boolDistToIntDist :: Dist Bool -> Dist Int
boolDistToIntDist (D boolDist) = D $ M.mapKeysMonotonic boolToInt boolDist

-- ------------------------------ 
-- EXAMPLE: 
-- ------------------------------

point :: (Ord a) => a -> Dist a
point x = D $ singleton x 1

-- later nog complexere distributies toevoegen. 
statement1 :: Int -> Dist Int
statement1 x = point (x + 1)

statement2 :: Int -> Dist Bool
statement2 x = point (x < 0)

statement3 :: Int -> Dist Int
statement3 x = point (x - 2)

statement4 :: Int -> Dist Int
statement4 x = point (x + 1)

program :: Kuifje Int
program
  = update' statement1 <>
    while   statement2 (
      update' statement3 <>
      update' statement4
    )

program' :: Kuifje Int
program' = Update statement1 (While statement2 (Update statement3 (Update statement4 (Skip))))

serialisedProgram :: String
serialisedProgram = "Update statement1 (While statement2 (Update statement3 (Update statement4 (Skip))))"

main :: IO ()
main = let 
  objProgram = P.parse kuifjeParser "" serialisedProgram 
  in case objProgram of
    Left  err   -> print err
    Right out   -> print (evaluate 0 out)



-- ---------------------------------
-- Calculator example
-- ---------------------------------

-- KAN DISTRIBUTIES NOG INTERSSANTER MAKEN.


-- -- Basic arithmetic operations

-- add :: Int -> Int -> Dist Int
-- add x y = D $ singleton (x + y) 1

-- subtract' :: Int -> Int -> Dist Int
-- subtract' x y = D $ singleton (x - y) 1

-- multiply :: Int -> Int -> Dist Int
-- multiply x y = D $ singleton (x * y) 1

-- divide :: Int -> Int -> Dist Int
-- divide x y = if y /= 0 then D $ singleton (x `div` y) 1 else D M.empty

-- -- Scientific functions

-- squareRoot :: Int -> Dist Float
-- squareRoot x = if x >= 0 then D $ singleton (sqrt $ fromIntegral x) 1 else D M.empty

-- power :: Int -> Int -> Dist Int
-- power x y = D $ singleton (x ^ y) 1

-- logarithm :: Int -> Dist Float
-- logarithm x = if x > 0 then D $ singleton (logBase 10 $ fromIntegral x) 1 else D M.empty 

-- -- Prime checking function

-- isPrime :: Int -> Bool
-- isPrime n
--   | n <= 1 = False
--   | otherwise = all (\x -> n `mod` x /= 0) [2..intSquareRoot n]

-- intSquareRoot :: Int -> Int
-- intSquareRoot = round . sqrt . fromIntegral

-- -- Kuifje program for the scientific calculator

-- calculatorProgram :: Kuifje Int
-- calculatorProgram =
--   let x = 17
--       y = 3
--   in update' (add x y) <>
--      update' (subtract' x y) <>
--      update' (multiply x y) <>
--      update' (divide x y) <>
--      update' (squareRoot x) <>
--      update' (power x y) <>
--      update' (logarithm x) <>
--      cond (\x -> isPrime x) (update' (\x -> x + 1)) (update' (\x -> x - 1))



-- quickCheck : 
-- 
-- 

-- Input Parsing: 
-- The parser you've implemented can be used to parse expressions entered by the user in the graphical interface. 
-- 

-- plotting: 
-- vb. bij calculator ipv 1 waarde terug te geven, geef een distributie terug. 
-- bv. 1 + 1 kan 0 -1 of 1 met gelijke kansen
-- als je die resultaat weer gebruikt bij andere operatie dan kansen zullen mss veranderen
-- opt einde heb je histogram van mogelijke antwoorden. 

-- Choose a Plotting Library: Select a Haskell plotting library such as haskell-plot or Chart. 
-- These libraries provide functions and types for creating a wide range of plots, including histograms, line charts, scatter plots, and heatmaps.



-- Extend the Evaluator: Modify the evaluator function to compute additional statistical metrics or 
-- data that can be used for plotting. For example, you may calculate the mean, median, variance, or 
-- other summary statistics of the stochastic processes or probability distributions.

-- dus kuifje language is om de calculator te builden en dan de parser neemt in the expressies
--  en voedt het in de parsed kuifje program. 















































-- -------------------------------------
-- robot example: 
-- -------------------------------------

-- ZAL NIET MEER DOEN.
-- IS BESLOTEN IS CALCULATOR. 



-- serialisedProgram :: String
-- serialisedProgram = "While maxEpisodesNotReached (While robotNotInTerminal (Update moveRobot (Skip))))"

-- maxEpisodesNotReached deterministic condition
-- robotNotInTerminal determinishtic condition
-- evaluator function that takes in this program calculates the total reward. 

-- skip retuns initial robot ?  



-- -- robot representation
-- type Position = (Int, Int)
-- data Action   = Up | Do | Le | Ri deriving (Eq, Ord)
-- data Robot    = Robot {
--   pos :: Position,
--   totalreward :: Int,
--   maze :: Maze
-- }

-- data Maze = Maze {
--     mazeGrid :: [[Bool]],
--     start :: Position,
--     trueEnd :: Position,
--     falseEnd :: Position
--  }

-- moveRobot :: Robot -> Maze -> Action -> Robot
-- moveRobot robot m action = let
--     oldpos    = pos robot
--     oldreward = totalreward robot
--     newpos    = move opos action
--     in
--       if isValidMove npos m
--         then Robot npos (reward npos m + oldreward) m
--         else Robot opos (opos : history robot) m

-- move :: Position -> Action -> Position
-- move (x,y) Up = (x,y+1)
-- move (x,y) Do = (x,y-1)
-- move (x,y) Ri = (x+1,y)
-- move (x,y) Le = (x-1,y)

-- isValidMove :: Position -> Maze -> Bool
-- isValidMove (x, y) maze = x >= 0 && y >= 0 && x < length (mazeGrid maze) && y < length (head (mazeGrid maze)) && (mazeGrid maze) !! x !! y

-- transition :: Action -> Dist Action
-- transition Up = D $ M.fromList [(Up, 0.8), (Le, 0.1), (Ri, 0.1), (Do, 0)]
-- transition Do = D $ M.fromList [(Do, 0.8), (Ri, 0.1), (Le, 0.1), (Up, 0)]
-- transition Ri = D $ M.fromList [(Ri, 0.8), (Do, 0.1), (Up, 0.1), (Le, 0)]
-- transition Le = D $ M.fromList [(Le, 0.8), (Up, 0.1), (Do, 0.1), (Ri, 0)]

-- reward :: Position -> Maze -> Double
-- reward state m
--   | state == trueEnd m  = 10
--   | state == falseEnd m = -10
--   | otherwise           = -0.05


-- statement :: Robot -> Action -> Robot
-- statement robot action =  let
--   nactionprobs = transition action
--   newState = sampleAction nactionprobs
--   in moveRobot robot (maze robot) newState

-- sampleAction :: Dist Action -> Action
-- sampleAction =  error "YTD"


-- -- Initial state of the robot
-- initialState :: Robot
-- initialState = Robot { pos = (0, 0), history = 0 }

-- -- Run the robot exploration in the maze
-- runRobot :: Int -> Maze -> Kuifje RobotState -> IO ()
-- runRobot steps maze strategy = do
--     let initialStateDist = D $ M.singleton initialState 1
--     finalDistribution <- iterateKuifje steps initialStateDist strategy
--     let finalState = M.foldrWithKey (\s p _ -> if p > 0 then s else []) (0, 0) (runD finalDistribution)
--     putStrLn $ "Final state: " ++ show finalState

-- -- Helper function to iterate Kuifje program
-- iterateKuifje :: Int -> Dist a -> Kuifje a -> IO (Dist a)
-- iterateKuifje 0 d _ = return d
-- iterateKuifje n d program = do
--     let (D d') = runD (execKuifje program) d
--     randomIndex <- randomRIO (0, M.size d' - 1)
--     let (state, _) = M.elemAt randomIndex d'
--     iterateKuifje (n-1) (D (M.singleton state 1)) program

-- main :: IO ()
-- main = runRobot 1000 maze (exploreStrategy maze initialState)


-- -- Robot's exploration strategy: Random walk until reaching the goal.
-- exploreStrategy :: Maze -> RobotState -> Kuifje RobotState
-- exploreStrategy maze state = updateState state <> observeReward state
--   where
--     updateState s = do
--         random_action sampleUniform [Up, Down, Left, Right]
--         nextState <- transition maze s action
--         return nextState
--     observeReward s = observe (\_ -> rewardFunction maze s)



-- -- bellmanEquation :: Maze -> Robot -> Double -> Double
-- -- bellmanEquation maze robot gamma =
-- --     let rewards = map (\action -> fromIntegral (reward maze (transition maze robot action))) [MoveUp, MoveDown, MoveLeft, MoveRight]
-- --         maxReward = maximum rewards
-- --     in fromIntegral (reward maze robot) + gamma * maxReward


-- doe het eerst zonder kuifje programma en daarna met. 
-- welke state is terminal ? etc. 

-- Input: lines "aa\nbb\nbb"
-- Output: ["aa","bb","bb"]

-- outer map for each string in list
-- inner map for each car in string
-- stringToMaze :: String -> Maze
-- stringToMaze str = map (map (\c -> c == ' ')) (lines str)

-- -- Input: unlines ["aa","bb","cc","dd","ee"]
-- -- Output: "aa\nbb\ncc\ndd\nee\n"

-- mazeToString :: Maze -> String
-- mazeToString maze = unlines (map (map (\b -> if b then ' ' else '#')) maze)


-- main :: IO ()
-- main =
--   let stringMaze = "#####\n#   #\n# # #\n#   #\n#####\n"
--       maze = stringToMaze stringMaze
--       stringRepresentation = mazeToString maze
--   in putStrLn stringRepresentation